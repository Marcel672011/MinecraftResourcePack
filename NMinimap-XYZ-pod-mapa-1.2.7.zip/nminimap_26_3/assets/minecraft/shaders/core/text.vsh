#version 330
#define UNREL_ID
#define NO_PARAMS
#define ADD_SHIFT

#define MAP_DEPTH 0.9999
#define MARKER_DEPTH 0.9999

#extension GL_ARB_separate_shader_objects : require

#include <nminimap:config.glsl>

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:globals.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

uniform sampler2D Sampler0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

layout(location = 4) flat out int custom;
layout(location = 5) out vec2 uvCoord;
layout(location = 6) flat out vec3 b_meta;
layout(location = 7) flat out vec4 box;

#include <nminimap:vertex_utils.glsl>

void main() {
    custom = 0;
    uvCoord = vec2(0);
    b_meta = vec3(0);
    box = vec4(0);

    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
    
    #include <nminimap:vertex_body.glsl>
#else
    vertexColor = Color;
#endif

    // BuczekHUD XYZ 1.2.6: apply to both GUI/see-through and ordinary text
    // render paths. Previously the transform only ran in the #else branch,
    // while the ActionBar on this client could use the other path.
    vec3 hudLabelMarker = vec3(0.0, 1.0, 0.0); // #00FF00 from BuczekHUD
    vec3 hudValueMarker = vec3(1.0, 0.0, 1.0); // #FF00FF from BuczekHUD

    // Minecraft draws a dark shadow pass at roughly 25% of the source RGB.
    bool hudLabelShadow = distance(Color.rgb, hudLabelMarker * 0.25) < 0.035;
    bool hudValueShadow = distance(Color.rgb, hudValueMarker * 0.25) < 0.035;
    bool hudLabel = distance(Color.rgb, hudLabelMarker) < 0.035;
    bool hudValue = distance(Color.rgb, hudValueMarker) < 0.035;

    if (hudLabelShadow || hudValueShadow) {
        // Fully suppress the old shadow so it cannot remain at the old location.
        vertexColor = vec4(1.0, 1.0, 1.0, 0.0);
    } else if (hudLabel || hudValue) {
        // Coordinates are sent in the ActionBar at the screen center.
        // Map center from the user's 1648x925 capture: x~=1485 px.
        // Target is just below the map's bottom edge: y~=330 px.
        // ScreenSize excludes the OS title bar/taskbar, so source Y is -0.506.
        vec2 originalCenter = vec2(0.0, -0.506);
        vec2 targetCenter = vec2(0.803, 0.288);
        vec2 ndcPosition = gl_Position.xy / gl_Position.w;
        ndcPosition = (ndcPosition - originalCenter) * 0.75 + targetCenter;
        gl_Position.xy = ndcPosition * gl_Position.w;

        // The labels are green; numbers are white.
        vertexColor = hudLabel
            ? vec4(0.35, 1.0, 0.35, Color.a)
            : vec4(1.0, 1.0, 1.0, Color.a);
    }

    texCoord0 = UV0;
}
